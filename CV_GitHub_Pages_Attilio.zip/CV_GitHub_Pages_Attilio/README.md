# CV online — Attilio Michele Simonetti

Questo repository contiene il CV digitale in formato statico HTML.

## Pubblicazione rapida con GitHub Pages

1. Crea un nuovo repository su GitHub chiamato `TUO_USERNAME.github.io`.
2. Carica il file `index.html` nella root del repository.
3. Vai in Settings > Pages.
4. Seleziona Deploy from a branch.
5. Branch: `main`; Folder: `/root`.
6. Salva e attendi qualche minuto.

Il CV sarà disponibile all'indirizzo:
`https://TUO_USERNAME.github.io/`
